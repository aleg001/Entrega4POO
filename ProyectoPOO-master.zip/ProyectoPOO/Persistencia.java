//Imports
import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.BufferedReader;
//import java.nio.charset.Charset;
import java.util.ArrayList;
import java.nio.file.*;
import java.io.IOException;
import java.lang.Integer;
//Nuevos imports
import java.io.FileWriter;
//import java.util.Arrays;

 public class Persistencia{

   //Propiedades
   private PrintWriter pw;
   private String directorio;
   private String linea;
   private String celda;
   private ArrayList<ArrayList<String>> datos;
   private Path path;
   private BufferedReader lector;
   //private FileWriter fr;

   //Constructor
   public Persistencia(String nombreArchivo){
      // Se inicializa el directorio donde se guardaran los archivos.
      //Path currentRelativePath = Paths.get("");
      //String s = currentRelativePath.toAbsolutePath().toString();
      //File d = new File(s);
      // String[] listaNombres =  d.list();
      File f = new File(nombreArchivo);
      if(f.exists()){          
         /*
          Archivo ya existe, no hace n
            */

            try{
               datos = new ArrayList<ArrayList<String>>();
               path = Paths.get(nombreArchivo);
               lector = Files.newBufferedReader(path);

            }catch(IOException io){
               System.out.println("Ha ocurrido un error al cargar los datos.");
            }

            try{
               datos = new ArrayList<ArrayList<String>>();
               path = Paths.get(nombreArchivo);
               lector = Files.newBufferedReader(path);

            }catch(IOException io){
               System.out.println("Ha ocurrido un error al cargar los datos.");
            }

         }else{
            directorio = nombreArchivo;
            try {
               pw = new PrintWriter(new File(directorio));
               String encabezado = "Codigo,Nombre,Apellido,Telefono,Correo"+"\r\n";
               pw.write(encabezado);
               System.out.println("Archivo "+nombreArchivo+" creado.");

            } catch (Exception e) {
               System.out.println("Error.");
            }

            //segundo try con excepcion diferente, para identificar si cargan los datos.
            try{
               datos = new ArrayList<ArrayList<String>>();
               path = Paths.get(nombreArchivo);
               lector = Files.newBufferedReader(path);

            }catch(IOException io){
               System.out.println("Ha ocurrido un error al cargar los datos.");
            }
         }
      
   }

   //Metodo que añade un nuevo registro al usuarios.csv . Recibe una instancia del objeto
   public void nuevoRegistro( usuarioSamaj user ){
      try{
         String cod = Integer.toString(user.getCodigo());
         String nombre = user.getNombre();
         String apellido = user.getApellido();
         String tel = Integer.toString(user.getTelefono());
         String correo = user.getCorreo();
         String fila = cod+","+nombre+","+apellido+","+tel+","+correo+"\r\n";

         //Añade la fila en modo append
         File archivo = new File("Usuario.csv");
         FileWriter fw = new FileWriter(archivo.getAbsoluteFile() , true);
         fw.write(fila);
         fw.close();
         
      }catch(IOException io){
         System.out.println("No se ha logrado ingresar nueva informacion");
      }
   }

   

   // Metodo que devuelve un ArrayList de ArrayList con los datos del archivo dentro.
   public ArrayList<ArrayList<String>> obtenerDatos(){
      try{
         while((linea = lector.readLine()) != null){
            ArrayList<String> filaTemporal = new ArrayList<String>();
            for(int i = 0; i<(linea.length()) ; i++){
               if((linea.charAt(i))==',' || i == (linea.length()-1)){
                  filaTemporal.add(celda);
                  celda = "";
               }else{
                  celda += ""+linea.charAt(i);
               }
            }
            datos.add(filaTemporal);
         }

      }catch(IOException io){
         System.out.println("Error al leer los datos.");
      }

      return datos;
   }

   //Cierra el printWriter evitar errores.
   //Ejecutarlo al finalizar el programa, es  muy importante.
   public void cerrarPrintWriter(){
      pw.close();
   }

  
   /* Método para registrar un trabajador Formal en el csv
   * @author Alejandra Guzman
   */
   public void NuevoRegistroFormal( TrabajadorFormal userSamaj) {
      try{
         String cod = Integer.toString(userSamaj.getCodigo());
         String nombre = userSamaj.getNombre();
         String apellido = userSamaj.getApellido();
         String tel = Integer.toString(userSamaj.getTelefono());
         String correo = userSamaj.getCorreo();
         int edad = userSamaj.getEdad();
         int NivelEducacion = userSamaj.getNivelEducacion();
         int idiomas = userSamaj.getIdiomas();
         boolean transporte = userSamaj.getTransporte();
         boolean HomeOffice = userSamaj.getHomeOffice();
         String fila = cod + ", " + nombre + ", " + apellido +", " + tel + ", " + correo + ", " + edad + ", " + NivelEducacion+ ", " + idiomas + ", " + transporte + ", " + HomeOffice +"\r\n";

         //añadir fila a modo Append 

         File archivo = new File("PerfilesFormal.csv");
         FileWriter fw = new FileWriter(archivo.getAbsoluteFile() ,  true);
         fw.write(fila);
         fw.close();
       } catch(IOException io){
          System.out.println("No se ha conseguido ingresar la nueva informacion");
       } 

   }

   /* Método para registrar un Trabajo Temporal en el csv
   * @author Paola de Leon y Marco Jurado 
   */
  public void NuevoRegistroTrabajoTemp( TrabajoTemp trabajito) {
   try {
      String nombre = trabajito.getNombre();
      String tel = Integer.toString(trabajito.getTelefono());
      String categoria = trabajito.getCategoriaTrabajo();
      String descripcion = trabajito.getDescripcionTrabajo();
      String sueldo = Integer.toString(trabajito.getSueldo());
      String fila =  nombre + ", " + tel + ", " + categoria + ", " + descripcion + ", " + sueldo;

      /*Tomar el ArrayList de aplicantes del objeto TrabajoTemp
        y extraer el nombre y número de telefono de cada uno de
        estos para que sean almacenados en el registro.  Estos
        serán añadidos fila para ser metidos al registro.   */

      ArrayList<usuarioSamaj> aplicantes = trabajito.getAplicantes();
      for (int i = 0; i < aplicantes.size(); i++) {
         usuarioSamaj h = aplicantes.get(i);
         String nom = h.getNombre();
         String telef = Integer.toString(h.getTelefono());
         fila += ", " + nom + ", " + telef;
      }

      fila += "\r\n";
      //añadir fila a modo Append 

      File archivo = new File("Usuario.csv");
      FileWriter fw = new FileWriter(archivo.getAbsoluteFile() ,  true);
      fw.write(fila);
      fw.close();
    } catch(IOException io){
       System.out.println("No se ha conseguido ingresar la nueva informacion");
    } 

}
   
}

